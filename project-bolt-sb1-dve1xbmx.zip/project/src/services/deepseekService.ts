interface ReadingParams {
  birthDate: string;
  birthTime?: string;
  sex: 'male' | 'female';
  zodiacSign: string;
  zodiacSymbol: string;
}

export async function generateReading(params: ReadingParams) {
  const prompt = `Generate a detailed horoscope reading for a ${params.sex} born on ${params.birthDate} ${params.birthTime ? `at ${params.birthTime}` : ''} with zodiac sign ${params.zodiacSign} ${params.zodiacSymbol}. Include:

1. Three Tarot cards with detailed interpretations
2. Daily recommendations for:
   - Love life (considering relationship status)
   - Financial matters (career and money)
   - Health and wellness (physical and spiritual)
3. A meditation focus for the day
4. An inspirational thought
5. A message from guardian angels
6. A famous person with the same zodiac sign and their story

The response should be in JSON format with the following structure:
{
  "tarotCards": [
    { "name": string, "description": string }
  ],
  "recommendations": {
    "love": string,
    "money": string,
    "health": string
  },
  "meditation": string,
  "thoughtOfDay": string,
  "angelMessage": string,
  "famousPerson": {
    "name": string,
    "description": string
  }
}`;

  try {
    const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 2000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to generate reading');
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error('Error generating reading:', error);
    throw error;
  }
}