import React, { useState } from 'react';
import { getZodiacSign } from '../utils/zodiac';
import { generateReading } from '../services/deepseekService';

interface ReadingFormData {
  birthDate: string;
  birthTime: string;
  sex: 'male' | 'female' | '';
}

function ReadingPage() {
  const [formData, setFormData] = useState<ReadingFormData>({
    birthDate: '',
    birthTime: '',
    sex: ''
  });
  const [reading, setReading] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const zodiacInfo = getZodiacSign(formData.birthDate);
      const reading = await generateReading({
        birthDate: formData.birthDate,
        birthTime: formData.birthTime || undefined,
        sex: formData.sex as 'male' | 'female',
        zodiacSign: zodiacInfo.name,
        zodiacSymbol: zodiacInfo.symbol
      });
      setReading(reading);
    } catch (err) {
      setError('Failed to generate your reading. Please try again later.');
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        {!reading ? (
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-8 shadow-xl">
            <h2 className="text-3xl font-bold mb-6 text-center">Your Daily Reading</h2>
            
            {error && (
              <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-100">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="birthDate" className="block text-sm font-medium mb-2">
                  Date of Birth *
                </label>
                <input
                  type="date"
                  id="birthDate"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                  className="w-full px-4 py-2 rounded-md bg-white/5 border border-white/20 focus:border-purple-500 focus:ring-purple-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="birthTime" className="block text-sm font-medium mb-2">
                  Time of Birth (Optional)
                </label>
                <input
                  type="time"
                  id="birthTime"
                  value={formData.birthTime}
                  onChange={(e) => setFormData({ ...formData, birthTime: e.target.value })}
                  className="w-full px-4 py-2 rounded-md bg-white/5 border border-white/20 focus:border-purple-500 focus:ring-purple-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Sex *</label>
                <div className="space-x-4">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="sex"
                      value="female"
                      checked={formData.sex === 'female'}
                      onChange={(e) => setFormData({ ...formData, sex: 'female' })}
                      className="form-radio text-purple-500"
                      required
                    />
                    <span className="ml-2">Female</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="sex"
                      value="male"
                      checked={formData.sex === 'male'}
                      onChange={(e) => setFormData({ ...formData, sex: 'male' })}
                      className="form-radio text-purple-500"
                    />
                    <span className="ml-2">Male</span>
                  </label>
                </div>
              </div>
              
              <button
                type="submit"
                disabled={loading}
                className={`w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-full font-semibold transition-opacity ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:opacity-90'}`}
              >
                {loading ? 'Generating Reading...' : 'Get Your Reading'}
              </button>
            </form>
          </div>
        ) : (
          <div className="bg-white/10 backdrop-blur-md rounded-lg p-8 shadow-xl space-y-6">
            <h2 className="text-3xl font-bold mb-6 text-center">
              Your Daily Reading
              <span className="ml-2 text-yellow-300">{reading.zodiacSymbol}</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {reading.tarotCards.map((card: any, index: number) => (
                <div key={index} className="bg-white/5 p-4 rounded-lg text-center">
                  <h3 className="font-semibold mb-2">{card.name}</h3>
                  <p className="text-sm text-gray-300">{card.description}</p>
                </div>
              ))}
            </div>
            
            <div className="space-y-4">
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Love for Today</h3>
                <p className="leading-relaxed text-gray-300">{reading.recommendations.love}</p>
              </div>
              
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Money for Today</h3>
                <p className="leading-relaxed text-gray-300">{reading.recommendations.money}</p>
              </div>
              
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Health for Today</h3>
                <p className="leading-relaxed text-gray-300">{reading.recommendations.health}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Meditation of the Day</h3>
                <p className="leading-relaxed text-gray-300">{reading.meditation}</p>
              </div>
              
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Thought for the Day</h3>
                <p className="leading-relaxed text-gray-300">{reading.thoughtOfDay}</p>
              </div>
              
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Message from Your Angels</h3>
                <p className="leading-relaxed text-gray-300">{reading.angelMessage}</p>
              </div>
              
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-xl">Famous {reading.zodiacSign}</h3>
                <p className="leading-relaxed text-gray-300">
                  <span className="font-semibold">{reading.famousPerson.name}</span>: {reading.famousPerson.description}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default ReadingPage;