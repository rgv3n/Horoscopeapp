import React from 'react';
import { useNavigate } from 'react-router-dom';

function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-8">
          <img 
            src="https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=800&q=80"
            alt="Magical Night Sky"
            className="rounded-lg shadow-2xl mx-auto mb-8"
          />
        </div>
        
        <div className="bg-white/10 backdrop-blur-md rounded-lg p-8 shadow-xl">
          <div className="mb-8">
            <img 
              src="https://images.unsplash.com/photo-1583195764036-6dc248ac07d9?auto=format&fit=crop&w=400&q=80"
              alt="Cute Witch"
              className="rounded-full w-32 h-32 mx-auto object-cover"
            />
          </div>
          
          <h1 className="text-4xl font-bold mb-6">Welcome to Mystic Readings</h1>
          <p className="text-lg mb-8">Let the stars guide your path and reveal your daily fortune</p>
          
          <button
            onClick={() => navigate('/reading')}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3 rounded-full font-semibold hover:opacity-90 transition-opacity"
          >
            Your Daily Horoscope
          </button>
        </div>
      </div>
    </div>
  );
}

export default HomePage