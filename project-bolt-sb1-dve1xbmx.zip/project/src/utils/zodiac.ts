interface ZodiacSign {
  name: string;
  symbol: string;
  startDate: { month: number; day: number };
  endDate: { month: number; day: number };
}

const zodiacSigns: ZodiacSign[] = [
  { name: 'Aries', symbol: '♈', startDate: { month: 3, day: 21 }, endDate: { month: 4, day: 19 } },
  { name: 'Taurus', symbol: '♉', startDate: { month: 4, day: 20 }, endDate: { month: 5, day: 20 } },
  { name: 'Gemini', symbol: '♊', startDate: { month: 5, day: 21 }, endDate: { month: 6, day: 21 } },
  { name: 'Cancer', symbol: '♋', startDate: { month: 6, day: 22 }, endDate: { month: 7, day: 22 } },
  { name: 'Leo', symbol: '♌', startDate: { month: 7, day: 23 }, endDate: { month: 8, day: 22 } },
  { name: 'Virgo', symbol: '♍', startDate: { month: 8, day: 23 }, endDate: { month: 9, day: 22 } },
  { name: 'Libra', symbol: '♎', startDate: { month: 9, day: 23 }, endDate: { month: 10, day: 23 } },
  { name: 'Scorpius', symbol: '♏', startDate: { month: 10, day: 24 }, endDate: { month: 11, day: 21 } },
  { name: 'Sagittarius', symbol: '♐', startDate: { month: 11, day: 22 }, endDate: { month: 12, day: 21 } },
  { name: 'Capricornus', symbol: '♑', startDate: { month: 12, day: 22 }, endDate: { month: 1, day: 19 } },
  { name: 'Aquarius', symbol: '♒', startDate: { month: 1, day: 20 }, endDate: { month: 2, day: 18 } },
  { name: 'Pisces', symbol: '♓', startDate: { month: 2, day: 19 }, endDate: { month: 3, day: 20 } }
];

export function getZodiacSign(birthDate: string): { name: string; symbol: string } {
  const date = new Date(birthDate);
  const month = date.getMonth() + 1; // JavaScript months are 0-based
  const day = date.getDate();

  // Handle Capricorn's special case (spans December-January)
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) {
    return { 
      name: 'Capricornus', 
      symbol: '♑' 
    };
  }

  const sign = zodiacSigns.find(sign => {
    if (sign.startDate.month === month && sign.endDate.month === month) {
      return day >= sign.startDate.day && day <= sign.endDate.day;
    }
    if (sign.startDate.month === month) {
      return day >= sign.startDate.day;
    }
    if (sign.endDate.month === month) {
      return day <= sign.endDate.day;
    }
    return false;
  });

  return sign ? { name: sign.name, symbol: sign.symbol } : { name: 'Unknown', symbol: '?' };
}