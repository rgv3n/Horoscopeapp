import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Star, Sparkles } from 'lucide-react';
import HomePage from './pages/HomePage';
import ContactPage from './pages/ContactPage';
import ReadingPage from './pages/ReadingPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-b from-indigo-900 via-purple-900 to-pink-900 text-white">
        <nav className="p-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Star className="text-yellow-300" />
            <span className="text-xl font-bold">Mystic Readings</span>
          </div>
          <div className="flex items-center space-x-4">
            <Sparkles className="text-yellow-300" />
          </div>
        </nav>
        
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/reading" element={<ReadingPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;